#!/bin/sh
ecmd="echo "; i=$(basename $0)

if [ -x /etc/custom/custfunc.sh ]; then
	. /etc/custom/custfunc.sh
	ecmd="echm ${i} "
fi


$ecmd "board MAC private SAMPLE: $1 (firstboot|startup|shutdown|upgrade)" #sleep 5




case "$1" in

    firstboot)
        test -f /root/.firstboot.$i && exit 0
        :
        touch /root/.firstboot.$i
    ;; #upgraded) :; ;;


    startup)
        :
    ;; #touch /root/.startup.$i


    startuponce) #note: not fully functional -> wip
        test -f /root/.startup.once.$i && exit 0
        :
        touch /root/.startup.once.$i
    ;;


    shutdown) :; ;;


    upgrade) :; ;;


    shutdown) :; ;;


    upgrade) :; ;;

esac




exit 0








#touch /root/.firstboot.$i
############ actually this is complicated
	#- most of the script is a detect eth1 and write config (if not present etc wan6... defaults)
	#- has extra "PRIVATE" wan settings -> macrun<-sh..dca.... OR/and wrt.ini "WANMACalt" etc.
	#-parts of rpi-network... config writer need to be ucified here

############################################ NOTE: all this code moved here from .../firstboot/911-rpi-wanfixups
###################################################### internal case "MYMAC" not needed... as called from macrun
###################################################### nor most of the rest... copy up only "do" code... etc.



MODEL=$(cat /etc/board.json | jsonfilter -e '@["model"]["id"]')


#tplink,archer-c5-v2

case $MODEL in
    *"c5-v2"*) VENDOR=c5-v2; NIC=eth0; ;;
    tl-*|archer-*)  VENDOR=tplink; NIC=eth1; ;;
    cf-*) VENDOR=comfast; NIC=eth0; ;;
    *rt2600ac*) VENDOR=synology; NIC=eth1.1; ;;
    *nbg6817*) VENDOR=zyxtel; NIC=eth0; ;;
    *raspberrypi*) VENDOR=rpi; NIC=eth0; ;;
    *4-model-b*) VENDOR=rpi4; NIC=eth0; ;;
    *innotek*) VENDOR=pc; NIC=eth0; ;;
    *) VENDOR=ap; NIC=eth0; ;;
esac
#raspberrypi,4-model-b



MACADDR=$(cat /sys/class/net/$NIC/address | sed -e 's/://g')
HOSTNAME="$VENDOR-${MACADDR:-nomac}"

$ecmd "Model:$MODEL Vendor:$VENDOR Nic:$NIC Mac:$MACADDR Hostname: $HOSTNAME"; sleep 2


fixupwanrpi() {

    uci -q set network.wan=interface
    uci -q set network.wan.ifname='eth1'
    uci -q set network.wan.proto='dhcp'
    uci -q set network.wan.hostname='router'
    uci -q set network.wan.macaddr='00:11:32:96:42:65'
    uci -q set network.wan6=interface
    uci -q set network.wan6.ifname='eth1'
    uci -q set network.wan6.proto='dhcp6'
    uci -q set network.wan6.macaddr='00:11:32:96:42:65'
    uci commit network
}
##################################################### /etc/config/dhcp
#dhcp.lan.dhcpv6='server'
#dhcp.lan.ra='server'
#dhcp.lan.ra_slaac='1'
#dhcp.lan.ra_flags='managed-config' 'other-config'
#################################################### /etc/config/network
#network.lan.ip6assign='60'
#############################################
#network.globals.ula_prefix='fda9:424a:1c04::/48'
#############################################
#    uci -q set network.wan6=interface
#    uci -q set network.wan6.ifname='eth1'
#    uci -q set network.wan6.proto='dhcp6'
#    uci -q set network.wan6.macaddr='00:11:32:96:42:65'


fixupwanrpigenscriptmethod() {
cat <<EOF >/wansetup.sh
#!/bin/sh

uci commit
/etc/init.d/network restart
EOF
chmod +x /wansetup.sh
$ecmd "sh /wansetup.sh"
}


checkforeth1() {
    if ifconfig -a | grep -q '^eth1'; then
        #$ecmd "eth1 [present]"
        return 0
    else
        #$ecmd "eth1 [not-present]"
        return 1
    fi
}



checkconfignetworknowan() {
    if cat /etc/config/network | grep -q 'wan'; then
        #$ecmd "config/network [wan-present]"
        return 1
    else
        #$ecmd "config/network [wan-not-present]"
        return 0
    fi
}






case "$VENDOR" in
    rpi)
        $ecmd "VENDOR: $VENDOR MODEL: $BOARD"; sleep 2
        #$ecmd "wan interface fixups"
        case "$MACADDR" in
            dca632563177)
                $ecmd "lanmac verify ok [$MACADDR]"
                #checkforeth1
                #checkconfignetworknowan
                if checkforeth1 && checkconfignetworknowan; then
                    $ecmd "Do need to add wan"
                    fixupwanrpi
                else
                    $ecmd "No need to add wan"
                fi
            ;;
            *)
                $ecmd "lanmac verify fail [$MACADDR]"
            ;;
        esac

    ;;
esac




exit 0
touch /root/.firstboot.$i
exit 0







network.mng7=interface
network.mng7.ifname='eth0.7'
network.mng7.proto='static'
network.mng7.hostname='mng7'
network.mng7.ipaddr='10.7.7.1'
network.mng7.netmask='255.255.255.0'


firewall.@zone[0].network='lan' 'mng7' 'spare'
config zone
    option name 'lan'
	list network 'lan'
	list network 'mng7'
	list network 'spare'













#!/bin/sh


#[  322.139086] r8152 2-2:1.0 eth1: carrier on




ULAPREFIX='fda9:424a:1c04::/48'		#for most of the router configs
LANIP="10.2.3.13"			#for not gateway > rpinetlan





snapcurrentnet() {
	echo "backing up last config-network /etc/config-network-`date +%Y%m%d-%H%M`"
	cp /etc/config/network /etc/config-network-`date +%Y%m%d-%H%M`
}






rpinetlandhcpclient() {

/etc/init.d/dnsmasq disable
/etc/init.d/dnsmasq stop
/etc/init.d/odhcpd disable
/etc/init.d/odhcpd stop

snapcurrentnet

cat <<'EOF' > /etc/config/network

config interface 'loopback'
        option ifname 'lo'
        option proto 'static'
        option ipaddr '127.0.0.1'
        option netmask '255.0.0.0'

config globals 'globals'

config interface 'lan'
        option type 'bridge'
        option ifname 'eth0'
        option proto 'dhcp'
        option hostname 'router'

EOF

/etc/init.d/network restart

}




rpinetlan() {

/etc/init.d/dnsmasq disable
/etc/init.d/dnsmasq stop
/etc/init.d/odhcpd disable
/etc/init.d/odhcpd stop


snapcurrentnet
cat <<EOF > /etc/config/network

config interface 'loopback'
        option ifname 'lo'
        option proto 'static'
        option ipaddr '127.0.0.1'
        option netmask '255.0.0.0'

config globals 'globals'

config interface 'lan'
        option type 'bridge'
        option ifname 'eth0'
        option proto 'static'
        option ipaddr ${LANIP}
        option netmask '255.255.255.0'
        option hostname 'router'

config interface 'mng7'
	option ifname 'eth0.7'
	option proto 'static'
	option hostname 'mng7'
	option ipaddr '10.7.7.1'
	option netmask '255.255.255.0'

EOF

/etc/init.d/network restart

}





rpinetdefaultdhcp() {

/etc/init.d/dnsmasq enable
/etc/init.d/dnsmasq start
/etc/init.d/odhcpd enable
/etc/init.d/odhcpd start


snapcurrentnet
cat <<EOF > /etc/config/network

interface 'loopback'
        option ifname 'lo'
        option proto 'static'
        option ipaddr '127.0.0.1'
        option netmask '255.0.0.0'

config globals 'globals'
        option ula_prefix ${ULAPREFIX}

config interface 'lan'
        option type 'bridge'
        option ifname 'eth0'
        option proto 'static'
        option ipaddr '192.168.1.1'
        option netmask '255.255.255.0'
        option ip6assign '60'
        option hostname 'router'
        option delegate '0'

EOF

/etc/init.d/network restart

}




rpinetdefaultnodhcp() {

/etc/init.d/dnsmasq disable
/etc/init.d/dnsmasq stop
/etc/init.d/odhcpd disable
/etc/init.d/odhcpd stop


snapcurrentnet
cat <<EOF > /etc/config/network

interface 'loopback'
        option ifname 'lo'
        option proto 'static'
        option ipaddr '127.0.0.1'
        option netmask '255.0.0.0'

config globals 'globals'
        option ula_prefix ${ULAPREFIX}

config interface 'lan'
        option type 'bridge'
        option ifname 'eth0'
        option proto 'static'
        option ipaddr '192.168.1.1'
        option netmask '255.255.255.0'
        option ip6assign '60'
        option hostname 'router'
        option delegate '0'

EOF

/etc/init.d/network restart

}







rpinetwan() {

/etc/init.d/dnsmasq enable
/etc/init.d/dnsmasq start
/etc/init.d/odhcpd enable
/etc/init.d/odhcpd start


snapcurrentnet
cat <<EOF > /etc/config/network

config interface 'loopback'
        option ifname 'lo'
        option proto 'static'
        option ipaddr '127.0.0.1'
        option netmask '255.0.0.0'

config globals 'globals'
        option ula_prefix ${ULAPREFIX}

config interface 'lan'
        option type 'bridge'
        option ifname 'eth0'
        option proto 'static'
        option ipaddr '10.2.3.1'
        option netmask '255.255.255.0'
        option ip6assign '60'
        option hostname 'router'
        option delegate '0'

config interface 'mng7'
	option ifname 'eth0.7'
	option proto 'static'
	option hostname 'mng7'
	option ipaddr '10.7.7.1'
	option netmask '255.255.255.0'

config interface 'wan'
        option ifname 'eth1'
        option proto 'dhcp'
        option hostname 'router'
        option macaddr '00:11:32:96:42:65'

 config interface 'wan6'
        option ifname 'eth1'
       option proto 'dhcpv6'

EOF

/etc/init.d/network restart

}






if [ "$1" = "gateway" ]; then
    rpinetwan
elif [ "$1" = "lanclient" ]; then
    rpinetlan; sleep 12; ifconfig br-lan
elif [ "$1" = "lanclientdhcp" ]; then
    rpinetlandhcpclient; sleep 12; ifconfig br-lan
elif [ "$1" = "rpinetdefaultdhcp" ]; then
	rpinetdefaultdhcp
elif [ "$1" = "rpinetdefaultnodhcp" ]; then
	rpinetdefaultnodhcp
else
    echo "$0 [gateway|lanclientdhcp|lanclient|rpinetdefaultdhcp|rpinetdefaultnodhcp]"
fi







exit 0

#dhcp.lan.dhcpv6='server'
#dhcp.lan.ra='server'
#dhcp.lan.ra_slaac='1'
#dhcp.lan.ra_flags='managed-config' 'other-config'




















