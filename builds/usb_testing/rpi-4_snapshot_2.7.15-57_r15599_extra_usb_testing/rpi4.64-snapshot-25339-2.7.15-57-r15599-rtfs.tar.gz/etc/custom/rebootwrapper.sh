#!/bin/sh



WRAPn="$0"
bNAME="$(basename $0)"

SHUTscr="/etc/custom/shutdown.sh"








#DEBUG=1
[ -n "$DEBUG" ] && RCSLEEP=1














eKO() {
	#[ -n "$DEBUG" ] && echo "$bNAME ${*}"
	[ -n "$DEBUG" ] && echo "consoleonly-$bNAME ${*}" > /dev/console
}













#@@@ case what we were called as...
case "$bNAME" in
    reboot)
        :
    ;;
    halt)
        :
    ;;

    *)
        eKO "OOOOOOOOOOOOOOOOOOOOOOOO: $0 ${*}"; sleep 7
    ;;
esac
#eKO "PAYLOADCMD(early): /bin/busybox ${bNAME} ${@}"; sleep ${RCSLEEP:-0}








board_name=$(cat /tmp/sysinfo/board_name)
case "$board_name" in *"4-model-b"*) ISRPI4=1; ;; esac #echo "board_name: $board_name ISRPI4=$ISRPI4" > /dev/console



if [ "$(pwd)" = "/tmp/root" ]; then #eKO ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>> all done"
    ISTMPFS=1
fi



#if [ ! -z "$ISRPI4" ]; then
# probable-triplecheckcmdline.txtHASNOINVALIDPARTUUIDhere due to config restore
#fi








if [ ! -z "$ISTMPFS" ]; then
    eKO ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>> all done"
elif [ ! -z "$ISRPI4" ] && [ -f "$SHUTscr" ]; then
    eKO "RUNNING: $SHUTscr plog"; $SHUTscr plog
    eKO "RUNNING: $SHUTscr shutdown"; $SHUTscr shutdown
elif [ ! -z "$ISRPI4" ] && [ ! -f "$SHUTscr" ]; then
    eKO "pre-shutdown: $SHUTscr [missing]"; sleep ${RCSLEEP:-0}; #notDEBUG@eKO #20210129alsonotrpi4
else
    eKO "pre-shutdown: $SHUTscr [leave-nonrpi4-wip-testforpsavevarfallbacks]"; sleep ${RCSLEEP:-0}
    echo "pre-shutdown: $SHUTscr [leave-nonrpi4-wip-testforpsavevarfallbacks]" > /dev/console
fi; sleep ${RCSLEEP:-0}



#####if [ ! -z"$ISRPI4" ] && [ -f "$SHUTscr" ]; then #if [ -f "$SHUTscr" ]; then #NOTE: wrapthisstuffforRPI4onlybutprintconsoleifnot
######@shutdown.shPLOG||PDIRetcalternativescheck
######maynotwork@elseabove -> dbg find board_name

################### OLDLOGICPREISRPI4
################### OLDLOGICPREISRPI4
################### OLDLOGICPREISRPI4
################### OLDLOGICPREISRPI4
################### OLDLOGICPREISRPI4
################### OLDLOGICPREISRPI4
#####################if [ ! -z "$ISRPI4" ] && [ -f "$SHUTscr" ]; then
#if [ -f "$SHUTscr" ]; then #NOTE: wrapthisstuffforRPI4onlybutprintconsoleifnot
#    eKO "RUNNING: $SHUTscr plog"; $SHUTscr plog
#    eKO "RUNNING: $SHUTscr shutdown"; $SHUTscr shutdown
#else
#    if [ "$(pwd)" = "/tmp/root" ]; then
#        : #called from sysupgrade end
#        eKO ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>> all done"
#    else
#        eKO "pre-shutdown: $SHUTscr [missing]"; sleep ${RCSLEEP:-0}; #notDEBUG@eKO #20210129alsonotrpi4
#    fi
#fi; sleep ${RCSLEEP:-0}




































/bin/busybox ${bNAME} ${@}




eKO "done -> test-exit0" ###NEVERREACHHERE
sleep 2 #dbgslpforce
exit 0











#!/bin/sh



########################################################
#reboot /sbin/reboot > /bin/busybox
#halt /sbin/halt > /bin/busybox
#shutdown no x64 or rpi
########################################################
#0 */6 * * * /etc/init.d/rrdbackup backup
##############################




WRAPn="$0"

SHUTscr="/etc/custom/shutdown.sh"







########################################### as param1
#bNAME="${1}"; #shift; #echo "iam:$WRAPn calling: $bNAME ${@}"; #sleep 2



bNAME="$(basename $0)"

DEBUG=1
[ -n "$DEBUG" ] && RCSLEEP=1







eKO() {
	#[ -n "$DEBUG" ] && echo "$bNAME ${*}"
	[ -n "$DEBUG" ] && echo "consoleonly-$bNAME ${*}" > /dev/console
}










#@@@ case what we were called as...
case "$bNAME" in
    reboot)
        :
    ;;
    halt)
        :
    ;;

    *)
        eKO "OOOOOOOOOOOOOOOOOOOOOOOO: $0 ${*}"; sleep 7
    ;;
esac











#eKO "PAYLOADCMD(early): /bin/busybox ${bNAME} ${@}"; sleep ${RCSLEEP:-0}


if [ -f "$SHUTscr" ]; then #eKO "pre-shutdown: $SHUTscr"

    #$SHUTscr downearly



    #FIRSTBOOT IS A BETTERPLACE TO FIXUP THESE VARS in INI ONCE ONLY
    #############################################################################################
    #if [ -z "$LOGPERSIST" ]; then
    #    LOGPERSIST="/boot/plog"
    #    eKO "workaround LOGPERSIST:$LOGPERSIST wasz > /boot/plog"
    #elif [ "$LOGPERSIST" != '/boot/plog' ]; then

    #if [ ! -z "$LOGPERSIST" ] && [ "$LOGPERSIST" != '/boot/plog' ]; then
    #    eKO "workaround LOGPERSIST:$LOGPERSIST > /boot/plog"
    #    LOGPERSIST="/boot/plog"
    #fi #PSAVEDIR="/boot/psave"; fi; [ -n "$DEBUG"  ] && echq "PSAVEDIR=\"${PSAVEDIR}\""
    #############################################################################################


    eKO "RUNNING: $SHUTscr plog"
    $SHUTscr plog


    ########NOTE THIS IS DONE IN SHUTDOWN.SH NOW
    ##mkdir -p /restorefiles/plog
    ##cp -urf ${LOGPERSIST}/* /restorefiles/plog
    ##sync

    eKO "RUNNING: $SHUTscr shutdown"
	$SHUTscr shutdown #check it can find caller || not called from init.d debug print calling from here too...


else


    if [ "$(pwd)" = "/tmp/root" ]; then
        : #called from sysupgrade end
        eKO ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>> all done"
    else
        #notDEBUG@eKO
        eKO "pre-shutdown: $SHUTscr [missing]"; sleep ${RCSLEEP:-0}
    fi

fi
sleep ${RCSLEEP:-0}



#####3#probably veryfy -x early #eKO "PAYLOADCMD: /bin/busybox ${bNAME} ${@}" #sleep 7; sleep ${RCSLEEP:-0}
/bin/busybox ${bNAME} ${@}



###################################exit $? ??? #sleep ${RCSLEEP:-0}; sleep ${RCSLEEP:-0}; sleep ${RCSLEEP:-0}
###NEVERREACHHERE
eKO "done -> test-exit0"
sleep 2 #dbgslpforce
exit 0













#echo "$WRAPn ${*}"
#echo "$WRAPn 1: ${1}"
###############################
#WRAPn="/usr/sbin/reboot"
#WRAPn="/usr/sbin/$(basename $0)"
################################





################Usage: halt||reboot [-d DELAY] [-n] [-f]
#Halt the system
#	-d SEC	Delay interval
#	-n	Do not sync
#	-f	Force (don't go through init)
############################################/lib/upgrade/do_stage2:echo b 2>/dev/null >/proc/sysrq-trigger
###########root@pc-0800273dbd /# cat /lib/upgrade/do_stage2 | grep -C5 sysrq
#v "Rebooting system..."
#umount -a
#reboot -f
#sleep 5
#echo b 2>/dev/null >/proc/sysrq-trigger



##################
#    plog<shutdown) #init.d/persistdata?>LOGPERSIST? ######################################## init.d/persistdata boot|shutdown ~upgraded
                #LOGPERSIST (dirnotz)
#
#        [ -n "$DEBUG" ] && echSH "called from init.d persistdata: ${*}"
#        if [ -z "$LOGPERSIST" ]; then
#            echSH "logpersist [empty]"
#            [ -n "$DEBUG" ] && echSH "dbg sleep 3" && sleep 3
#            return 0
#        fi
#
#        mkdir -p "${LOGPERSIST}" || return 0
#        DSTAMP=$(date +%Y%m%d%H%M)
 #       LOGLINES=$(logread | wc -l)
#
#
#        echo "DBG dumping ${LOGPERSIST}/plogread-${DSTAMP}.log lines:$LOGLINES" > /dev/console && sleep 5


#        echSH "dumping ${LOGPERSIST}/plogread-${DSTAMP}.log lines:$LOGLINES" #sleep 2
#        logread > "${LOGPERSIST}"/plogread-${DSTAMP}.log
#
#        echSH "size: $(du -cs ${LOGPERSIST}/plogread-${DSTAMP}.log | head -n1)" #sleep 2
#        return 0
######################







    #echo "pwd"; pwd #pwd /tmp/root
    #we may be in tmpfs for sysupgrade :) detect and skipcheck(earlier->or do something else :)
    #? eKO "pre-shutdown: mount: $(mount)"; sleep ${RCSLEEP:-0}
    #zero eKO "pre-shutdown: ps-w: $(ps w)"; sleep ${RCSLEEP:-0}
    #echo "ls"; ls; sleep 5
    #echo "pwd"; pwd #pwd /tmp/root
    #noCMD> echo "df -h"; df -h
    #echo "sleep 55"; sleep 55






