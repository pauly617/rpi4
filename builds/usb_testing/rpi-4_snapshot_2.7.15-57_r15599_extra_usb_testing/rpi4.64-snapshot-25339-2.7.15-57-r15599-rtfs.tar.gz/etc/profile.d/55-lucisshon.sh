






if [ -f /bin/luci-sshon.sh ]; then

    #maybe curl >null to init background img

    sh /bin/luci-sshon.sh start
	#sh /bin/luci-sshon.sh start &
fi



#ls
#ls2
#dfdfls2
#dfdfls2
#dfdfls2
#dfdfls2



