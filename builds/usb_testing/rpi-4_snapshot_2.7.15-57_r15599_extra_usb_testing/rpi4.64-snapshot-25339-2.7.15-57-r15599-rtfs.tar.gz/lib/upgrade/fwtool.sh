





fwtool_check_signature() {
	[ $# -gt 1 ] && return 1


	[ ! -x /usr/bin/ucert ] && {
		if [ "$REQUIRE_IMAGE_SIGNATURE" = 1 ]; then
		    v "ucert not available"
			return 1
		else
            v "ucert-no-avail"
            return 0
		fi
	}


	if ! fwtool -q -s /tmp/sysupgrade.ucert "$1"; then
		v "Image signature not present"
		[ "$REQUIRE_IMAGE_SIGNATURE" = 1 -a "$FORCE" != 1 ] && {
			v "Use sysupgrade -F to override this check when downgrading or flashing to vendor firmware"
		}
		[ "$REQUIRE_IMAGE_SIGNATURE" = 1 ] && return 1
		return 0
	fi



    THEKEY=$(fwtool -q -T -s /dev/null "$IMG" | \
	        ucert -V -m - -c "/tmp/sysupgrade.ucert" -P /dev/null 2>/dev/null | \
	        cut -d"'" -f2 | sed 's!/dev/null/!!g')

    if [ -z "$THEKEY" ]; then
        THEKEY="$(strings "/tmp/sysupgrade.ucert" 2>/dev/null | head -n1 | tail -c17 2>/dev/null)"
    fi


    KEYMSG="$THEKEY"




    #@@@ if '# fake certificate'hashnot17 then curl shasums etc #if ! fwtool -q -i /tmp/sysupgrade.meta "$1"; then


    #NOTE 1>/dev/null stop 2xOK may break something else
	if ! fwtool -q -T -s /dev/null "$1" | \
		ucert -V -m - -c "/tmp/sysupgrade.ucert" -P /etc/opkg/keys 2>/dev/null 1>/dev/null; then
        KEYMSG="$KEYMSG /etc/opkg/keys[no]"
    else
        KEYMSG="$KEYMSG /etc/opkg/keys[ok]"; VALIDgotKEY=1
    fi

    if [ -d /etc/custom/keys ]; then
        #v "Checking for /etc/custom/keys"
        if ! fwtool -q -T -s /dev/null "$1" | \
		ucert -V -m - -c "/tmp/sysupgrade.ucert" -P /etc/custom/keys 2>/dev/null 1>/dev/null; then
            KEYMSG="$KEYMSG /etc/custom/keys[no]" #v "$THEKEY /etc/custom/keys [no]"
        else
            KEYMSG="$KEYMSG /etc/custom/keys[ok]" #v "$THEKEY /etc/custom/keys [ok]"
            VALIDgotKEY=1
        fi
    else
        KEYMSG="$KEYMSG /etc/custom/keys[nodir]" #v "$THEKEY /etc/custom/keys [ok]"
    fi


    if [ -z "$VALIDgotKEY" ]; then #if [ "$?" -ne 0 ]; then #if [ "$retval" -ne 0 ]; then #if [ "$?" -ne 0 ]; then
        retval=2
        v "validate-fail $KEYMSG" #v "image-key: $THEKEY oddball"
        if echo $KEYMSG | grep -q 'fake certificate'; then
	        v 'Use sysupgrade <-R> -F [official-image]'
        fi
    else
        v "validate-good $KEYMSG" #v "image-key: $THEKEY oddball"
		retval=0
	fi

    return $retval
}
#return $?



#cp "/tmp/sysupgrade.ucert" "/tmp/sysupgrade.ucert.test2"
#OFFICIAL
#strings /tmp/sysupgrade.ucert.test2 # fake certificate





fwtool_check_image() {
	[ $# -gt 1 ] && return 1

	. /usr/share/libubox/jshn.sh

	if ! fwtool -q -i /tmp/sysupgrade.meta "$1"; then
		v "Image metadata not present"
		[ "$REQUIRE_IMAGE_METADATA" = 1 -a "$FORCE" != 1 ] && {
			v "Use sysupgrade -F to override this check when downgrading or flashing to vendor firmware"
		}
		[ "$REQUIRE_IMAGE_METADATA" = 1 ] && return 1
		return 0
	fi

	json_load "$(cat /tmp/sysupgrade.meta)" || {
		v "Invalid image metadata"
		return 1
	}

	device="$(cat /tmp/sysinfo/board_name)"
	devicecompat="$(uci -q get system.@system[0].compat_version)"
	[ -n "$devicecompat" ] || devicecompat="1.0"

	json_get_var imagecompat compat_version
	json_get_var compatmessage compat_message
	[ -n "$imagecompat" ] || imagecompat="1.0"

	# select correct supported list based on compat_version
	# (using this ensures that compatibility check works for devices
	#  not knowing about compat-version)
	local supported=supported_devices
	[ "$imagecompat" != "1.0" ] && supported=new_supported_devices
	json_select $supported || return 1

	json_get_keys dev_keys
	for k in $dev_keys; do
		json_get_var dev "$k"
		if [ "$dev" = "$device" ]; then
			# major compat version -> no sysupgrade
			if [ "${devicecompat%.*}" != "${imagecompat%.*}" ]; then
				v "The device is supported, but this image is incompatible for sysupgrade based on the image version ($devicecompat->$imagecompat)."
				[ -n "$compatmessage" ] && v "$compatmessage"
				return 1
			fi

			# minor compat version -> sysupgrade with -n required
			if [ "${devicecompat#.*}" != "${imagecompat#.*}" ] && [ "$SAVE_CONFIG" = "1" ]; then
				v "The device is supported, but the config is incompatible to the new image ($devicecompat->$imagecompat). Please upgrade without keeping config (sysupgrade -n)."
				[ -n "$compatmessage" ] && v "$compatmessage"
				return 1
			fi

			return 0
		fi
	done

	v "Device $device not supported by this image"
	vn "Supported devices:"
	for k in $dev_keys; do
		json_get_var dev "$k"
		_vn " $dev"
	done
	_v

	return 1
}















#cp "/tmp/sysupgrade.ucert" "/tmp/sysupgrade.ucert.test"
#strings "/tmp/sysupgrade.ucert.test" 2>/dev/null | head -n1 | tail -c17 2>/dev/null
#NO THEKEY="$(strings "/tmp/sysupgrade.ucert" 2>/dev/null | tail -n1 | tail -c20 2>/dev/null)"

#if [ -z "$THEKEY" ] && [ ! -z "$(command -v usign 2>/dev/null)" ]; then
#fi


#ORIGINAL-fails-on-noucert
#THEKEY=$(fwtool -q -T -s /dev/null "$IMG" | \
#        ucert -V -m - -c "/tmp/sysupgrade.ucert" -P /dev/null 2>&1 | \
#        cut -d"'" -f2 | sed 's!/dev/null/!!g')

############### backwards
#local ="$1"
#[ -n "$key" ] || usage
#[ -f "$key" ] || echo "Cannot open file $1"
#local fingerprint="$(usign -F -p "$key")"
#mkdir -p "$OPKG_KEYS"
#cp "$key" "$OPKG_KEYS/$fingerprint"
















