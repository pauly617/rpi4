return{
	name="DnsCryptCa-DNS1",
	label=_("DNSCrypt.ca (DNS1)"),
	resolver_url="https://dns1.dnscrypt.ca:453/dns-query",
	bootstrap_dns="45.76.37.222,185.112.145.13,93.95.226.53,2001:19f0:5001:185a:5400:ff:fe50:56d5",
	help_link="https://dnscrypt.ca/",
	help_link_text="dnscrypt.ca"
}
