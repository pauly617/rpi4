return {
	name = "AdGuard-Standard",
	label = _("AdGuard (Standard)"),
	resolver_url = "https://dns.adguard.com/dns-query",
	bootstrap_dns = "176.103.130.130,176.103.130.131",
	help_link = "https://adguard.com/en/adguard-dns/overview.html",
	help_link_text = "AdGuard.com"
}
