return {
	name = "LibreDNS (No Ads)",
	label = _("LibreDNS (No Ads)"),
	resolver_url = "https://doh.libredns.gr/ads",
	bootstrap_dns = "116.202.176.26",
	help_link = "https://libredns.gr/",
	help_link_text = "LibreDNS.gr"
}
