#!/usr/bin/perl
use strict;
use LWP::UserAgent;
use HTTP::Request::Common qw(POST GET DELETE);


#/sys/devices/virtual/thermal/cooling_device0/cur_state
#/sys/devices/virtual/thermal/cooling_device0/max_state

#/sys/devices/virtual/thermal/thermal_zone0/temp


my @meas;

my $hostname = GetLineFrom('/proc/sys/kernel/hostname');

my $fan_cur = GetLineFrom('/sys/devices/virtual/thermal/cooling_device0/cur_state');
my $fan_max = GetLineFrom('/sys/devices/virtual/thermal/cooling_device0/max_state');
my $temp = GetLineFrom('/sys/devices/virtual/thermal/thermal_zone0/temp');                   # temperature is in millicelcius

my $fanpc = int(100 * $fan_cur / $fan_max + .5);


$fan_cur .= 'i';
$fan_max .= 'i';
$temp .= 'i';
$fanpc .= 'i';

push @meas, "rasp_pi,host=$hostname fancur=$fan_cur,fanmax=$fan_max,fanpc=$fanpc,temp=$temp";

print join "\n", @meas;
print "\n";

WriteInflux("192.168.1.12", "host", @meas);

exit 0;

sub GetLineFrom {
    my $path = shift;
    
    open FILE, $path or die "$path: $!\n";
    
    my $ret;
    
    while(<FILE>) {
        chomp;
        $ret = $_;
        last;
    }
    
    close FILE;
    return $ret;
}


sub WriteInflux {
    my $server = shift;
    my $db = shift;
    my @dat = @_;
    
    my $body = join "\n", @dat;
    
    my $url = "http://$server:8086/write?db=$db";
    
    my $ua = LWP::UserAgent->new;
    my $req = (POST $url, Content=>$body);
    my $res = $ua->request($req);
    
    print "code: ", $res->code, "\n";
    print "content: ", $res->content, "\n";
    
}

