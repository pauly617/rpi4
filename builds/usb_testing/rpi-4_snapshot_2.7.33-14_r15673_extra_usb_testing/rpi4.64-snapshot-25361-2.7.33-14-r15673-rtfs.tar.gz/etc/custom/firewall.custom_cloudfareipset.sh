#/bin/sh






















# name of the ipset - v4 or v6 will be appended.
IPSET_NAME=cloudflare-

# argument: v4 or v6 (defaults to v4)
cloudflare_ipset ()
{
        local ipv
        local inetv

        if [ -z "$1" ]; then ipv="v4"; else ipv="$1"; fi

        if [ "$ipv" == 'v4' ]
                then inetv="inet"
                else inetv="inet6"
        fi

        IPSET_NAME="$IPSET_NAME$ipv"

        local content_re='^[0-9a-f:.\r\n/ ]+$'

        local url="https://www.cloudflare.com/ips-$ipv"
        local ipdata; # local is a command that affects $?, so must be separate!
        


	#echo "curl --fail \"$url\" 2>/dev/null"
	ipdata=$(curl --fail "$url" 2>/dev/null | tr -s "[:space:]" " ")
        local ret=$?

        #if [ $ret -eq 0 ] && [[ $ipdata =~ $content_re ]]; then #FAILS



        if [ $ret -eq 0 ]; then


		if ipset list $IPSET_NAME 2>/dev/null 1>/dev/null
                then
                        echo "Updating $IPSET_NAME set..."
                        ipset flush $IPSET_NAME
                else
                        echo "Creating $IPSET_NAME set..."
                        ipset create $IPSET_NAME hash:net family $inetv
                fi


       # local url="https://www.cloudflare.com/ips-$ipv"

       if [ "$ipv" = "v4" ]; then



                for i in $ipdata
                do
                        #ipset add $IPSET_NAME $i
                        #ipset add $IPSET_NAME "$i" #ip6fix
                        echo "ipset add $IPSET_NAME \"$i\"" #ip6fix
                        ipset add $IPSET_NAME "$i" #ip6fix
                done



	else
               	
		#echo "$ipdata"
    		#exit 0
		#echo $ipdata | while read i; do
		curl --fail "$url" 2>/dev/null | while read i; do
                        #ipset add $IPSET_NAME $i
                        #ipset add $IPSET_NAME "$i" #ip6fix
                        echo "ipset add $IPSET_NAME \"$i\"" #ip6fix
                        ipset add $IPSET_NAME "$i" #ip6fix
                done

	fi




                local count=`ipset list $IPSET_NAME | wc -l`
                count=$((count-7))
                echo "Set $IPSET_NAME now has $count entries."
                return 0
        else
                echo "Download failed, sets not modified."
                return 1
        fi
}








cloudflare_ipset "$1"
cloudflare_ipset "v6"

exit $?











exit 0





























iptables -t mangle -I PREROUTING -p tcp -m set --match-set cloudflare-v4 dst  -j DSCP --set-dscp-class CS6
ip6tables -t mangle -I PREROUTING -p tcp -m set --match-set cloudflare-v6 dst  -j DSCP --set-dscp-class CS6
iptables -t mangle -I PREROUTING -p tcp -m conntrack --ctstate NEW -m set --match-set cloudflare-v4 dst -j LOG --log-prefix 'CLOUDFLARE '
ip6tables -t mangle -I PREROUTING -p tcp -m conntrack --ctstate NEW -m set --match-set cloudflare-v6 dst -j LOG --log-prefix 'CLOUDFLARE6 '
exit 0










nope() {

iptables  -t mangle -N CLOUDFLARE 2>/dev/null
iptables  -t mangle -F CLOUDFLARE 2>/dev/null

ip6tables  -t mangle -N CLOUDFLARE 2>/dev/null
ip6tables  -t mangle -F CLOUDFLARE 2>/dev/null

echo "1"
iptables -t mangle -I PREROUTING -p tcp -m conntrack --ctstate NEW -j CLOUDFLARE
ip6tables -t mangle -I PREROUTING -p tcp -m conntrack --ctstate NEW -j CLOUDFLARE

echo "2"
iptables -A CLOUDFLARE ! -m set --match-set cloudflare-v4 dst -j RETURN
ip6tables -A CLOUDFLARE ! -m set --match-set cloudflare-v6 dst -j RETURN
#iptables -t mangle -A CLOUDFLARE ! -m set --match-set cloudflare-v4 dst -j RETURN
#ip6tables -t mangle -A CLOUDFLARE ! -m set --match-set cloudflare-v6 dst -j RETURN

echo "3"
iptables -A CLOUDFLARE -j LOG --log-prefix 'NEWCLOUDFLARE '
ip6tables -A CLOUDFLARE -j LOG --log-prefix 'NEWCLOUDFLARE6 '


exit 0
iptables -A CLOUDFLARE -m set --match-set cloudflare-v4 dst -j LOG --log-prefix 'CLOUDFLARE '
ip6tables -A CLOUDFLARE -m set --match-set cloudflare-v6 dst -j LOG --log-prefix 'CLOUDFLARE6 '

#iptables -D FORWARD -m set --match-set cloudflare-v4 dst -j LOG --log-prefix 'CLOUDFLARE '
#ip6tables -D FORWARD -m set --match-set cloudflare-v6 dst -j LOG --log-prefix 'CLOUDFLARE6 '

#iptables -t mangle -I PREROUTING -p tcp -m conntrack --ctstate NEW -j CLOUDFLARE
#ip6tables -t mangle -I PREROUTING -p tcp -m conntrack --ctstate NEW -j CLOUDFLARE6
#ip6tables -t mangle -I PREROUTING -p tcp -m conntrack --ctstate NEW
#iptables -D FORWARD -m set --match-set cloudflare-v4 dst -j LOG --log-prefix 'CLOUDFLARE '
#ip6tables -D FORWARD -m set --match-set cloudflare-v6 dst -j LOG --log-prefix 'CLOUDFLARE6 '

}






















##########
#iptables -I FORWARD -m set --match-set cloudflare-v4 dst -j LOG --log-prefix 'CLOUDFLARE '
#ip6tables -I FORWARD -m set --match-set cloudflare-v6 dst -j LOG --log-prefix 'CLOUDFLARE6 '
########
#ipset save cloudflare-v4 >> /etc/custom/firewall/sqmdscp/ipsets/ipset.cloudfare-v4
#ipset save cloudflare-v6 >> /etc/custom/firewall/sqmdscp/ipsets/ipset.cloudfare-v6
#curl --fail "https://www.cloudflare.com/ips-v4" 2>/dev/null
#https://forum.openwrt.org/t/ultimate-sqm-settings-layer-cake-dscp-marks-new-script/53209/170?u=wulfy23
#is it possible to incorporate this into hisham script? Most game servers lead to cloudflare if you dig far enoug...
########









################# ORIGINAL-FAULTY-CURLFAIL




















# name of the ipset - v4 or v6 will be appended.
IPSET_NAME=cloudflare-

# argument: v4 or v6 (defaults to v4)
cloudflare_ipset ()
{
        local ipv
        local inetv

        if [ -z "$1" ]; then ipv="v4"; else ipv="$1"; fi

        if [ "$ipv" == 'v4' ]
                then inetv="inet"
                else inetv="inet6"
        fi

        IPSET_NAME="$IPSET_NAME$ipv"

        local content_re='^[0-9a-f:.\r\n/ ]+$'

        local url="https://www.cloudflare.com/ips-$ipv"
        local ipdata; # local is a command that affects $?, so must be separate!
        echo "curl --fail \"$url\" 2>/dev/null"

	ipdata=$(curl --fail "$url" 2>/dev/null | tr -s "[:space:]" " ")
        local ret=$?

        if [ $ret -eq 0 ] && [[ $ipdata =~ $content_re ]]; then
                if ipset list $IPSET_NAME 2>/dev/null 1>/dev/null
                then
                        echo "Updating $IPSET_NAME set..."
                        ipset flush $IPSET_NAME
                else
                        echo "Creating $IPSET_NAME set..."
                        ipset create $IPSET_NAME hash:net family $inetv
                fi
                for i in $ipdata
                do
                        ipset add $IPSET_NAME $i
                done

                local count=`ipset list $IPSET_NAME | wc -l`
                count=$((count-7))
                echo "Set $IPSET_NAME now has $count entries."
                return 0
        else
                echo "Download failed, sets not modified."
                return 1
        fi
}

cloudflare_ipset "$1"

exit $?
















#curl --fail "https://www.cloudflare.com/ips-v4" 2>/dev/null
#ipdata=$(curl --fail "$url" 2>/dev/null | tr -s "[:space:]" " ")


#curl --fail "https://www.cloudflare.com/ips-v4" 2>/dev/null | tr -s "[:space:]" " "






