#!/bin/sh
#uname -a
#uptime

uname -a
uptime




